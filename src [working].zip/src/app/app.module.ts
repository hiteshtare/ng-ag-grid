import { FormsModule } from '@angular/forms';
import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { AgGridModule } from "ag-grid-angular/main";
import { AppComponent } from "./app.component";
import { DateComponent } from "./date-component/date.component";
import { HeaderComponent } from "./header-component/header.component";
import { HeaderGroupComponent } from "./header-group-component/header-group.component";

@NgModule({
    declarations: [
        AppComponent,
        DateComponent,
        HeaderComponent,
        HeaderGroupComponent,
    ],
    imports: [
        BrowserModule,
        FormsModule, // <-- import the FormsModule before binding with [(ngModel)]
        AgGridModule.withComponents([
            DateComponent,
            HeaderComponent,
            HeaderGroupComponent,
        ])
    ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule {
}
